const enc=new TextEncoder();
const b64=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const hk=env=>crypto.subtle.importKey('raw',enc.encode(env.SESSION_SECRET||''),{name:'HMAC',hash:'SHA-256'},false,['sign']);
export const J=(o,h={},s=200)=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json','cache-control':'no-store',...h}});
export async function sign(env,obj){const p=b64(enc.encode(JSON.stringify(obj)));return p+'.'+b64(await crypto.subtle.sign('HMAC',await hk(env),enc.encode(p)))}
export async function verify(env,t){
  if(!t||!env.SESSION_SECRET)return null;const[p,s]=String(t).split('.');if(!p||!s)return null;
  if(b64(await crypto.subtle.sign('HMAC',await hk(env),enc.encode(p)))!==s)return null;
  try{const o=JSON.parse(atob(p.replace(/-/g,'+').replace(/_/g,'/')));return o.exp>Date.now()?o:null}catch{return null}
}
const PUSHER='https://ws-us2.pusher.com/app/32cbd69e4b950bf97679?protocol=7&client=js&version=8.4.0&flash=false';
export async function chatroomId(slug){
  const r=await fetch('https://kick.com/api/v2/channels/'+slug,{headers:{accept:'application/json','user-agent':'Mozilla/5.0'}});
  if(!r.ok)throw new Error('Kanal bilgisi alınamadı (HTTP '+r.status+')');
  const j=await r.json();return j.chatroom&&j.chatroom.id;
}
export async function listen(id,ms,onMsg,log){
  const r=await fetch(PUSHER,{headers:{Upgrade:'websocket'}});const ws=r.webSocket;
  if(!ws)throw new Error('WebSocket açılamadı');ws.accept();
  return new Promise(res=>{
    const t=setTimeout(()=>fin(null),ms);
    const fin=v=>{clearTimeout(t);try{ws.close()}catch{}res(v)};
    ws.addEventListener('message',e=>{
      let m;try{m=JSON.parse(e.data)}catch{return}
      if(log)log.push(m.event);
      if(m.event==='pusher:connection_established')ws.send(JSON.stringify({event:'pusher:subscribe',data:{auth:'',channel:'chatrooms.'+id+'.v2'}}));
      else if(m.event==='App\\Events\\ChatMessageEvent'){let d;try{d=JSON.parse(m.data)}catch{return}const v=onMsg(d);if(v)fin(v)}
    });
    ws.addEventListener('close',()=>fin(null));ws.addEventListener('error',()=>fin(null));
  });
}
