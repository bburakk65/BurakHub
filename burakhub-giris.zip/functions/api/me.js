import{verify,J}from'../_lib.js';
export async function onRequestGet({request,env}){
  const m=(request.headers.get('cookie')||'').match(/(?:^|; )bh=([^;]+)/);
  const o=m&&await verify(env,m[1]);
  return J({user:o?o.u:null});
}
