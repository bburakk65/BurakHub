import{verify,sign,chatroomId,listen,J}from'../../_lib.js';
const n=s=>String(s||'').toLowerCase().replace(/_/g,'-');
export async function onRequestPost({request,env}){
  const{token}=await request.json().catch(()=>({}));
  const t=await verify(env,token);
  if(!t)return J({status:'expired'});
  let id;try{id=await chatroomId(t.slug)}catch(e){return J({status:'error',message:e.message})}
  if(!id)return J({status:'error',message:'Kanal bulunamadı'});
  let hit;try{hit=await listen(id,40000,d=>n(d.sender&&d.sender.slug)===t.slug&&String(d.content||'').toUpperCase().includes(t.code)?d.sender.username:null)}
  catch(e){return J({status:'error',message:e.message})}
  if(!hit)return J({status:'waiting'});
  const sess=await sign(env,{u:hit,exp:Date.now()+30*864e5});
  return J({status:'ok',user:hit},{'set-cookie':`bh=${sess}; Path=/; Max-Age=2592000; HttpOnly; Secure; SameSite=Lax`});
}
