import{sign,J}from'../../_lib.js';
export async function onRequestPost({request,env}){
  if(!env.SESSION_SECRET)return J({error:'SESSION_SECRET ayarlanmamış'},{},500);
  const{slug}=await request.json().catch(()=>({}));
  const s=String(slug||'').trim().toLowerCase().replace(/^.*kick\.com\//,'').replace(/_/g,'-');
  if(!/^[a-z0-9-]{3,25}$/.test(s))return J({error:'Geçersiz Kick kullanıcı adı'},{},400);
  const a='ABCDEFGHJKMNPQRSTUVWXYZ23456789';let c='BH-';
  for(const x of crypto.getRandomValues(new Uint8Array(5)))c+=a[x%a.length];
  return J({code:c,token:await sign(env,{slug:s,code:c,exp:Date.now()+6e5})});
}
