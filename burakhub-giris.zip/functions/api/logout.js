import{J}from'../_lib.js';
export async function onRequestPost(){return J({ok:true},{'set-cookie':'bh=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax'})}
