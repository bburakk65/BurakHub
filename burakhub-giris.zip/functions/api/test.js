import{chatroomId,listen,J}from'../_lib.js';
export async function onRequestGet({request}){
  const slug=(new URL(request.url).searchParams.get('slug')||'').toLowerCase().replace(/_/g,'-');
  const out={slug};
  try{out.chatroom=await chatroomId(slug)}catch(e){out.chatroomHata=e.message}
  if(out.chatroom){const log=[];try{await listen(out.chatroom,4000,()=>null,log);out.olaylar=log}catch(e){out.wsHata=e.message}}
  return J(out);
}
